
public class CoatExperimentSimulator {
	private int numberOfPeople;

	public CoatExperimentSimulator(int numPpl) {
	}

	/**
	 * determines the number of people who got their coat back given an array that
	 * represents a random order. This permutation array will have the same length
	 * as the number of people in the experiment.
	 * 
	 * @param permutation
	 * @return
	 */
	public int numPplWhoGotTheirCoat(int[] permutation) {
		int sum = 0;
		for (int i = 0; i < permutation.length; i++) {
			if (permutation[i] == i + 1) {
				sum++;
			}
		}
		return sum;
	}

	/**
	 * this method simulates the coat problem multiple times and returns an array
	 * that contains the number of people who got their coats back in each
	 * experiment.
	 * 
	 * @param iterations
	 * @return
	 */
	public int[] simulateCoatExperiment(int iterations) {

		int[] n = new int[iterations];
		for (int i = 0; i < iterations; i++) {
			int[] a = RandomOrderGenerator.getRandomOrder(numberOfPeople);
			int b = numPplWhoGotTheirCoat(a);
			n[i] = b;
		}
		return n;
	}

	/**
	 * given the results of n iterations of the coats experiment, this computes the
	 * probability of 0 people getting their coats back by taking the number of
	 * times 0 people got their coats back in these n iterations and dividing that
	 * number by n
	 * 
	 * @param results
	 * @return
	 */
	public double answerToQuestionA(int[] results) {
		int num = 0;
		int denom = results.length;
		for (int i = 0; i < denom; i++) {
			if (results[i] == 0)
				num++;
		}
		double a = (double) num / denom;
		return a;
	}

	/**
	 * given the results of n iterations of the coats experiment, this computes the
	 * average number of people who get their coats back
	 * 
	 * @param results
	 * @return
	 */
	public double answerToQuestionB(int[] results) {
		int num = 0;
		int denom = results.length;
		for (int i = 0; i < denom; i++) {
			num += results[i];
		}
		double a = (double) num / denom;
		return a;
	}
}